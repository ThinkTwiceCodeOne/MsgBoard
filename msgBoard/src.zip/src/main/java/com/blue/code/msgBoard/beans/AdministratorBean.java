package com.blue.code.msgBoard.beans;
public class AdministratorBean
{
private String username;
private String password;
private String passwordKey;
public AdministratorBean()
{
}
public void setUsername(String username)
{
this.username=username;
}
public String getUsername()
{
return this.username;
}
public void setPassword(String password)
{
this.password=password;
}
public String getPassword()
{
return this.password;
}
public void setPasswordKey(String passwordKey)
{
this.passwordKey=passwordKey;
}
public String getPasswordKey()
{
return this.passwordKey;
}
}
