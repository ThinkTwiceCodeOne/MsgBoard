package com.blue.code.msgBoard;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsgBoardApplicationTests {

	@Test
	void contextLoads() {
	}

}
